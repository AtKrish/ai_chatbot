import re
import hashlib

from models.llm import llm
from services.cache import redis_client


CACHE_TTL = 3600  # 1 hour


def get_cache_key(user_query: str) -> str:
    query_hash = hashlib.md5(user_query.strip().lower().encode()).hexdigest()
    return f"rag:{query_hash}"


def ask_question(vector_db, user_query, chat_history):

    # -----------------------------
    # Check Redis Cache First
    # -----------------------------
    cache_key = get_cache_key(user_query)

    cached_answer = redis_client.get(cache_key)
    if cached_answer:
        return cached_answer

    # -----------------------------
    # Retrieve Documents
    # -----------------------------
    kb_match = re.search(r"\bKB\d+\b", user_query, re.IGNORECASE)

    if kb_match:
        requested_kb = kb_match.group(0).upper()

        all_docs = list(vector_db.docstore._dict.values())

        results = [
            doc
            for doc in all_docs
            if doc.metadata.get("kb_id", "").upper() == requested_kb
        ]
    else:
        results = vector_db.similarity_search(user_query, k=3)

    if not results:
        response = (
            "I could not find relevant information in the PDFs "
            "under the data folder."
        )

        redis_client.setex(cache_key, CACHE_TTL, response)
        return response

    # -----------------------------
    # Build Context
    # -----------------------------
    context_parts = []
    sources = []

    for doc in results:
        kb_id = doc.metadata.get("kb_id", "NOT AVAILABLE")
        ticket_id = doc.metadata.get("ticket_id", "NOT AVAILABLE")
        source = doc.metadata.get("source", "NOT AVAILABLE")
        author = doc.metadata.get("author", "NOT AVAILABLE")
        last_modified = doc.metadata.get("last_modified", "NOT AVAILABLE")

        sources.append(
            f"{kb_id} / {ticket_id} / {source} / Author: {author}"
        )

        context_parts.append(
            f"[KB: {kb_id} | Ticket: {ticket_id} | "
            f"Source: {source} | Author: {author} | "
            f"Last modified: {last_modified}]\n"
            f"{doc.page_content[:2500]}"
        )

    # -----------------------------
    # Author Lookup Shortcut
    # -----------------------------
    lowered_query = user_query.lower()

    if any(
        phrase in lowered_query
        for phrase in ["author", "authored", "who wrote"]
    ):
        for doc in results:
            author = doc.metadata.get("author", "NOT AVAILABLE")

            if author != "NOT AVAILABLE":
                response = (
                    f"{doc.metadata.get('kb_id', 'NOT AVAILABLE')} "
                    f"was authored by {author}. "
                    f"Source: {doc.metadata.get('source', 'NOT AVAILABLE')}. "
                    f"Ticket: {doc.metadata.get('ticket_id', 'NOT AVAILABLE')}."
                )

                redis_client.setex(cache_key, CACHE_TTL, response)
                return response

    # -----------------------------
    # LLM Prompt
    # -----------------------------
    context = "\n\n---\n\n".join(context_parts)
    source_list = "\n".join(f"- {source}" for source in sources)

    prompt = f"""
You are an IT support assistant.

Answer the user using only the PDF context below.
Do not use outside knowledge.

If the answer is not present in the PDF context, say:
"I could not find this in the available KB PDFs."

PDF context:
{context}

User Issue:
{user_query}

Answer in 5 short bullets or fewer.

Always include the source KB/Ticket when available.

Available retrieved sources:
{source_list}
"""

    response = llm.invoke(prompt)

    # -----------------------------
    # Store in Redis
    # -----------------------------
    redis_client.setex(cache_key, CACHE_TTL, str(response))

    return response